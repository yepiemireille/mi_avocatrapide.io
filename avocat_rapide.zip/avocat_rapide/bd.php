

<?php 

$conn = new PDO("mysql:host=localhost; dbname=avocat", "root", "");
session_start();
 ?>