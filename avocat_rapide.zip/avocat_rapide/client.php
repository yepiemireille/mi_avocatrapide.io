 <?php include("inc/header.php") ?>

	<h1>prendre rdv</h1>
	<br>
	<a href="index.php">Acceuil</a>


<section class="container md-6" >
	
<form action="" method="POST" style="padding: 20px" id="full_client">

	<div id="message" style="height: 80px; width: 200px"></div>

<div class="row mb-5 ">
	<div class="col md-6">
		<label for="" class="form-label text-primary">Nom et prenom</label>
		<input type="text" name="nom" id="full_nom">
	</div>

	<div class="col md-6">
		<label for="" class="form-label text-primary">Telephone</label>
		<input type="tel" name="tel" id="full_tel">
	</div>

	<div class="col md-6">
		<label for="" class="form-label text-primary">votre e-mail</label>
		<input type="email" name="email" id="full_email">
	</div>
</div>

<div class="row mb-5 ">

	<div class="col md-6">
		<label for="" class="form-label text-primary">un Avocat pour</label>
		<input type="text" name="raison" id="full_raison">
	</div>

<div class="col md-6">
		<label for="" class="text-primary">Description</label>
		<input type="text" name="description" id="full_description" style="height:300%">
	</div>
	<div class="col md-6">
		<label for="" class="form-label text-primary">type de ren-de-vous</label>
		<SELECT name="type_rdv" size="1">
<OPTION>en ligne (10.000Fr)
<OPTION>presentiel (50.000)
</SELECT>
	</div>
 </div>
 <button type="submit" class=" btn btn-primary" id="mysubmit" name="send" value="send"> Valider </button>
</form>

</section>
<?php include("inc/footer.php") ?>

