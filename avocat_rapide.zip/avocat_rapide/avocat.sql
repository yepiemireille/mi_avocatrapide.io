-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 26 oct. 2020 à 12:47
-- Version du serveur :  10.4.13-MariaDB
-- Version de PHP : 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `avocat`
--

-- --------------------------------------------------------

--
-- Structure de la table `avocatrapide`
--

CREATE TABLE `avocatrapide` (
  `id` int(11) NOT NULL,
  `preocupation` varchar(50) NOT NULL,
  `lois` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `avocatrapide`
--

INSERT INTO `avocatrapide` (`id`, `preocupation`, `lois`) VALUES
(1, 'mariage', 'zertyuiopwxcvbn,;:\r\nxcvbn,;:\r\nwxcvbn'),
(2, 'divorce ', 'sdjk\r\nwxcvbn,;\r\nsdfghjk'),
(3, 'mariage legale', 'ertyuio\r\nsdfghjk\r\nsdfghjk'),
(4, 'mariage coutumier', 'zertyuiop\r\nsdfghjkl\r\ndfghj'),
(5, 'separation de bien', 'ertyuio\r\ndfgfgj\r\nzertyuio\r\nsdfk'),
(6, 'divorce demarches', 'zertyuio\r\nsdfghjkl\r\nzertyui');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id_ar` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `raison` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `type_rdv` varchar(50) NOT NULL,
  `email_avocat_rdv` varchar(30) NOT NULL,
  `code_rdv` varchar(50) NOT NULL,
  `specialite` varchar(30) NOT NULL,
  `date_rdv` date DEFAULT NULL,
  `statut` varchar(2) NOT NULL,
  `fonction` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id_ar`, `nom`, `tel`, `email`, `raison`, `description`, `type_rdv`, `email_avocat_rdv`, `code_rdv`, `specialite`, `date_rdv`, `statut`, `fonction`) VALUES
(1, 'awa', '3456789', 'awa@awa', 'fghjk', 'dfghjk', 'en ligne (10.000Fr)', '', 'AR_16341', '', '2020-10-26', 'N', 'users'),
(2, 'valerie', '53136858', 'valerie@gmail.com', 'dfghjkl', 'fghjklm', 'presentiel (50.000)', 'ami@ami', 'AR_45734', '', '2020-10-26', 'P', 'users'),
(3, 'eli', '345678O', 'eli@eli', '', '', '', '', 'Cd_453', 'divorce', NULL, '', 'avocat'),
(4, 'ami', '9876543', 'ami@ami', '', '', '', '', 'Cd_456', 'immobiler', NULL, '', 'avocat'),
(5, 'ines', '34053194', 'ines@gmail.com', 'conseil le mariange', 'sdfghjklmrtyhjkl', 'presentiel (50.000)', 'ami@ami', 'AR_29097', '', '2020-10-26', 'N', 'users'),
(6, 'kira', '34053194', 'kira@kira', 'conseil', 'dfghjklm', 'en ligne (10.000Fr)', 'ami@ami', 'AR_38850', '', '2020-10-24', 'N', 'users'),
(11, 'eve', '3487654', 'eve@eve', 'sedrfghjklm', 'sdfghjklm', 'en ligne (10.000Fr)', 'eli@eli', 'AR_77948', '', '2020-10-26', 'P', 'users'),
(12, 'sahra', '3456789', 'sahra@gmail.com', 'sdfghjklm', 'xdcfvnwxcvnxcvn', 'en ligne (10.000Fr)', 'ami@ami', 'AR_72417', '', '2020-10-26', 'P', 'users'),
(13, 'valerie', '34053194', 'valerie@gmail.com', 'sdfghjklm', 'sdfghjklxcvn', 'presentiel (50.000)', 'eli@eli', 'AR_94093', '', '2020-10-27', 'P', 'users'),
(14, 'valerie', '345678', 'valerie@gmail.com', 'SDFGHJKL', 'DFGHJK\r\nCFGHJK', 'en ligne (10.000Fr)', 'ami@ami', 'AR_12097', '', NULL, 'N', 'users');

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `sender`, `receiver`, `message`, `date`) VALUES
(1, 'mireille@gmail.com', 'davila@gmail.com', 'salut mimi', '2020-10-23 22:26:33'),
(2, 'davila@gmail.com', 'mireille@gmail.com', 'ouai on dit quoi ?', '2020-10-23 22:27:04'),
(3, 'momo@momo', 'assatou@gmail.com', 'salut', '2020-10-24 09:50:04'),
(4, 'amed@amed', 'momo@momo', 'chui laa monsieur l\'avocat', '2020-10-24 10:04:13'),
(5, 'momo@momo', 'amed@amed', 'comment allez vous', '2020-10-24 10:04:53'),
(6, 'amed@amed', 'momo@momo', 'bonjour morelle, tla?', '2020-10-24 14:31:55'),
(7, 'ariane@gmail.com', 'dfghjkl@cvn', 'dre', '2020-10-24 22:48:58'),
(8, 'ariane@gmail.com', 'dfghjkl@cvn', 'salut andre', '2020-10-24 22:49:09'),
(9, 'dfghjkl@cvn', 'ariane@gmail.com', 'oui comment tu vas un bay hai', '2020-10-24 22:49:30'),
(10, 'eve@eve', 'eli@eli', 'bonjour', '2020-10-25 22:21:26'),
(11, 'eli@eli', 'eve@eve', 'comment allez vous?', '2020-10-25 22:21:51');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `avocatrapide`
--
ALTER TABLE `avocatrapide`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id_ar`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `avocatrapide`
--
ALTER TABLE `avocatrapide`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id_ar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
