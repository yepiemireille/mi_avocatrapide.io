<?php include("inc/header.php") ?>

<h2>Votre Ren-Dez-Vous a été enregistré avec success,

votre code du Ren-De-Vous est <?=$_SESSION['code_rdv']  ?>

 nous vous contacterons pour vous informer de la date</h2>

<button type="submit" class="btn btn-primary" id="mysubmit" name="send" value="send"><a style="text-decoration:none;color: white"; href="log_page_success.php"> Ok </a></button>
<br><br>

<?php include("inc/footer.php") ?>
