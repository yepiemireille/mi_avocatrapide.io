<?php
 include("bd.php");
 function verifie($donnees){
 
   $donnees = (string) $donnees;
         if (isset($donnees) && !empty($donnees)) {
           return $donnees;
         }
         else {
           return false;
         }

 }

$answer= null;

if (isset($_POST))
{
  $message= ' ';
	$nom = $_POST['nom'];
	$tel = $_POST['tel'];
	$email =  ($_POST['email']);
	$raison = ($_POST['raison']);
  $description =  ($_POST['description']);
  $type_rdv = ($_POST['type_rdv']);

// generer le code du ren-dez-vous
  $code='AR_'.rand(10000,99999);

   /* on test si les champ sont bien remplis */
    if(verifie($_POST['nom']) and verifie($_POST['tel'])  and verifie($_POST['email']) and verifie($_POST['raison'])and verifie($_POST['description'])and verifie($_POST['type_rdv']))
    {
                //On créé la requête
                $sql = 'INSERT INTO client(nom,tel,email,raison,description,type_rdv,code_rdv) VALUES ("'.$nom.'","'.$tel.'","'.$email.'","'.$raison.'","'.$description.'","'.$type_rdv.'","'.$code.'")';
                $result= $conn->query($sql);
                /*$result= mysqli_query($conn,$sql);*/ //version mysqli

            	if (!$result) {

            		$answer= "Query Failed";

            	}else {

   // insertion du 'users' et statut du ren de vous
              $fonction='users';
              $statut='N';
             
   $sq="UPDATE client SET fonction='{$fonction}',statut = '{$statut}' WHERE code_rdv ='{$code}'";
 $sql=$conn->query($sq);
                // affichage du code du client
                // 
                $search=$conn->query("SELECT * FROM client WHERE code_rdv = '{$code}'");
                // 
                      if ($search->rowCount() > 0) {

                      while($row=$search->fetch()) {
                       $_SESSION['code_rdv']=$row["code_rdv"];

              }


                       }
                //  
                $answer='ok';

 

              // 
 
              }
}
    else $answer= "Veuillez saisir tous les champs !"; 
}

$output=array('msg'=>$answer); 

echo json_encode($output);


?>