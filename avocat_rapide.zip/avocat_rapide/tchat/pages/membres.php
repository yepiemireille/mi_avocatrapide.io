 <?php
    if(isLogged() == 0){
        header("Location:index.php?page=signin");
    }
?>

<h2 class="header">Tous les membres</h2>
<?php
//***********en fonction du statut de la specialité {null ou pas} =>determiner la fonction de la personne venant de se connecter {avocat ou users} afin de limiter son acces a certains membres
$none='';
$date_du_jour=date("Y-m-d");
$ex=$_SESSION['tchat'];
$statut='P';

$search=$db->query("SELECT specialite FROM client WHERE email ='{$ex}'");
$searc=$search->fetchAll();
foreach ($searc as $key) {
    $sear=$key['specialite'];
}

# si l'utilisateur venant de se connecter est un avocat
if ($sear!=$none) {
    # code...


// ****************
    foreach(get_membres() as $membre){
        if($membre->email != $_SESSION['tchat']){
            // *****
            #email de l'avocat du rdv des membres trouvés dans la page membres doit etre identiques au mail de l'avocat connecté
if ($membre->email_avocat_rdv == $_SESSION['tchat']) {
    #date du rendez-vous des membres trouvés dans la page membres se doit d'etre identique a la date du jour
   if ($membre->date_rdv ==$date_du_jour) {
    #statut des membres trouvés dans la page membres se doit d'etre = [P]=>Progammer
       if ($membre->statut ==$statut) {
       
            // *****
            ?>
                <div class="membre">
                    <strong><?= $membre->nom ?></strong><br/>
                    <span><?= $membre->email ?></span><br/>
                    <a class="select" href="index.php?page=tchat&user=<?= $membre->email ?>"><span class="i-user"></span></a>
                </div>

            <?php

            // ******

       }
   }
}
            // ******
        }

    }
    // ***********
}

    // *********************************

#l'utilisateur venant de se connecter est un users
else {
    // ****
$dselect=$db->query("SELECT date_rdv FROM client WHERE email ='{$ex}'AND statut = '{$statut}' ");
$dsele=$dselect->fetchAll();
foreach ($dsele as $day) {
    $dspec=$day['date_rdv'];

    if ($dspec==$date_du_jour) {
        $dspec=$permissed;
    }else $dspec=$interd;
}
//     // ****
//  $cselect=$db->query("SELECT code_rdv FROM client WHERE email ='{$ex}'");
// $csele=$cselect->fetchAll();
// foreach ($csele as $row) {
//     $cspec=$row['code_rdv'];
// }
// $code=$_SESSION['code_rdv'];
//     // ******
//     $select=$db->query("SELECT email_avocat_rdv FROM client WHERE email ='{$ex}' AND code_rdv ='{$code}'");
// $sele=$select->fetchAll();
// foreach ($sele as $key) {
//     $spec=$key['email_avocat_rdv'];
// }

// ****************
    foreach(get_membres() as $membre){
        if($membre->email != $_SESSION['tchat']){
            // *****
if ($membre->email == $spec) {
   // if ($membre-> ==$date_du_jour) {
   //     if ($membre->statut ==$statut) {
       
            // *****
            ?>
                <div class="membre">
                    <strong><?= $membre->nom ?></strong><br/>
                    <span><?= $membre->email ?></span><br/>
                    <a class="select" href="index.php?page=tchat&user=<?= $membre->email ?>"><span class="i-user"></span></a>
                </div>

            <?php

            // ******

   //     }
   // }
}
            // ******
        }

    }
    // ***********
}
    // ***************




?>