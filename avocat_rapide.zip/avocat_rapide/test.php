 
<?php include("bd.php"); 


// $statut='P';
// $test='AR_'.rand(10000,99999);




//  $fonction='users';
//               $statut='P';
//    $code = 'AR_29097';         
 
// $sq="UPDATE client SET date_rdv=NOW() ";
//  $sql=$conn->query($sq);
// if ($sql) {
// 	echo "cool";
// }else echo "dommage";
// exit();
// $ex='ines@gmail.com';
// $search=$conn->query("SELECT specialite FROM client WHERE email ='{$ex}' ");
// $searc=$search->fetchAll();
// foreach ($searc as $key) {
// 	$sear=$key['specialite'];
// }

$date_du_jour=date("Y-m-d");
$ex='valerie@gmail.com';#session tchat
$statut='P';
$code='AR_45734';#=>session code AR_94093=>eli / AR_45734 =>ami
$dselect=$conn->query("SELECT email_avocat_rdv,date_rdv FROM client WHERE email ='{$ex}' && statut = '{$statut}' && code_rdv='{$code}' ");
$dsele=$dselect->fetchAll();
foreach ($dsele as $day) {
    $dspec=$day['date_rdv'];
    $espec=$day['email_avocat_rdv'];

  }  
if (isset($dspec)&&isset($espec)) {
	
	if ($dspec==$date_du_jour) {
		echo "Veuillez patienter, celui qui vous recoit est ".$espec;
		
	}else if ($dspec!=$date_du_jour) {
		echo "Votre rendez vous n'est pas pour aujourd'huit, veuillez reessayer le ".$dspec;
	}
		
	
	
}else echo "ce code n'est pas valide, plus d'infos voir la page ....gestion des RDV ";
// var_dump($dspec);
// var_dump($espec);

?>